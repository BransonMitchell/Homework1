package bmitchellhw1;
import java.util.*;
import java.io.*;

/**
 *This program is called UserLogin
 * @author Branson Mitchell
 * @version 09/06/2017
 * This program will accept user input to check if their login is valid through
 * use of boolean flags to determine if all parameters are met.
 */
public class UserLogin 
{
    
    public static void main(String[] args)throws IOException 
    {
        String userName;
        boolean moreUsers = false;
        
                
        System.out.println("This program will check to see if you have a valid user id."
                +"\nYour id must contain an Upper case letter, a lower case letter,"
                + " a number, a symbol in !@#$ and must be at least 5 characters long."
                + "When done entering user id's type Complete or complete.");
        
        //create a new input and accept user input for userName variable
        Scanner userInput = new Scanner(System.in);
        BufferedWriter userFile = new BufferedWriter(new FileWriter(new File("usernames.txt")));
        
        //testing that user input is accurately accepted
        //System.out.println(userName);
        
        while(moreUsers == false)
        {
            boolean number = false;
            boolean symbol = false;
            char letter;
            
            System.out.print("\nLogin: ");
            userName = userInput.nextLine();
            //testing that user input is accurately accepted
            //System.out.println(userName);
            StringBuffer users = new StringBuffer("Login: " + userName);
            

            //Testing whether characters in the string have the required valuse for a user name.   
            boolean capitalLetter = !userName.equals(userName.toLowerCase());
            //Test to see if the correct boolean value is returned based on uppercase letters
            //System.out.println(capitalLetter);
            boolean lowerCaseLetter = !userName.equals(userName.toUpperCase());
            //Test to see if the correct boolean value is returned based on lowercase letters
            //System.out.println(lowerCaseLetter);
            boolean stringLength = userName.length() >= 5;
            //Test to see if the correct boolean value is returned based on string length
            //System.out.println(stringLength);
            for(int i = 0; i < userName.length(); i++)
            {
                letter = userName.charAt(i);
                if(Character.isDigit(letter))
                {
                    number = true;
                } 
            }
            //Test to see if the correct boolean value is returned based on a number in string
            //System.out.println(number);
            if(userName.contains("!") || userName.contains("@") || userName.contains("#") || userName.contains("$"))
            {
                symbol = true;
            }
            //Test to see if the correct boolean value is returned based on a symbol in the string
            //System.out.println(symbol);
            
            //test if all values return correctly, and print that the name is valid if all are true.
            if(userName.contains("Complete") || userName.contains("complete"))
            {
                moreUsers = true;
            }
            
            if(capitalLetter == true &&  number == true && lowerCaseLetter == true && symbol == true && stringLength == true)
            {
                //System.out.println("Login: " + userName + " (valid)");
                users.append(" (valid)");
            }
            //test if false boolean returns encountered the error messages will display correctly
            else if(capitalLetter == false || number == false || lowerCaseLetter == false || symbol == false || stringLength == false)
            {
                //System.out.println("Login: " + userName + " (invalid)");
                users.append(" (invalid)");
                
                if(capitalLetter == false)
                {
                    //System.out.println("   -- No uppercase letter");
                    users.append("\n   -- No uppercase letter");
                }
                
                if(number == false)
                {
                    //System.out.println("   -- No digit");
                    users.append("\n   -- No digit");
                }
                
                if(lowerCaseLetter == false)
                {
                    //System.out.println("   -- No lowercase letter");
                    users.append("\n   -- No lowercase letter");
                }
                
                if(symbol == false)
                {
                    //System.out.println("   -- Invalid special character");
                    users.append("\n   -- Invalid special character");
                }
                
                if(stringLength == false)
                {
                    //System.out.println("   -- too short (must be at least 5 characters)");
                    users.append("\n   -- too short (must be at least 5 characters)");
                }
            }
        //test to make sure the string buffer is working correctly
        //System.out.print(users);
            userFile.write(users.toString());
            userFile.newLine();
        }
        userFile.flush();
        userFile.close();
    }
}
